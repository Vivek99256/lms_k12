# Pendulum Lab: your first simulation

This folder is a complete, working simulation. It is also the template you copy to make your own.
Open the sample in the Create screen first and play it. Then change one thing at a time.

A baseball hangs by a string from a laboratory retort stand on a workshop table, over a wooden floor. Every model is a real downloaded file, and the floor is a real material. The swing itself is worked out from **equations** (the other sample, Ramp Lab, uses a physics engine with solid bodies instead).

## What is in the folder

| File | What it is |
|---|---|
| `simulation.json` | The simulation itself: the controls, the equations, the pictures and the lesson. This is the file you edit. |
| `manifest.json` | A list of the model and picture files you use, with who made each one, under which licence and where it came from. |
| `assets/` | The files themselves: three 3D models (`.glb`), four pictures that make one floor material, and a studio sky. Only files listed in `manifest.json` belong here. |
| `recipe.json` | How the files in `assets/` were made from the downloaded originals (a size for each picture). Not needed to run it. |
| `README.md` | This note. It is optional and you can delete it. |

## The parts of `simulation.json`, in plain words

- **title, subtitle, summary, meta**: the name and the short description shown on the card. Change these first.
- **knobs**: the controls the learner moves. Here: string length, start angle, the world (Earth, Moon, Mars), the ball's mass and friction.
- **model**: the physics. `constants` says where the pivot is (the tip of the stand's arm, `hang` metres above the floor); `derived` works out gravity from the world and how big the ball is drawn; `state` lists what changes in time (the angle, the turning speed and the ball's place); `ode` says how fast each one changes; `events` notes each time the ball passes the lowest point; `outputs` are the numbers read off a finished swing, such as "Time of one swing".
- **charts**: the two graphs under the picture (angle and energy against time).
- **assets**: the 3D models and pictures used, each with a short name (`table`, `stand`, `ball`, `floor`, `sky`). The file itself is named in `manifest.json`. You never write the file's `sha256` by hand: the Create screen fills it in.
- **views**: how a swing is drawn. The first is the 3D picture: three `objects` placed where their formulas say (the ball follows the equations), a string drawn as a `ray` from the pivot to the ball, click-to-read `parts`, a floor with colour, bump, shininess and crevice maps (`scenes[0].ground`), and the lighting (`scenes[0].light`). The second is a flat side view with an arrow for the speed. The first one listed opens first.
- **flow**: the lesson, step by step: `intro`, `play` (free play), `predict`, two `mission` steps and `explain` (the closing questions). Each mission has goals, a start, and a `reference` answer that the checker uses to prove the mission can be solved.

## Change these first

1. `title`, `subtitle`, `summary` and the author name in `meta`.
2. The words of the `intro` step and of the two missions.
3. One number in a mission: for example the target time of mission 1 (`0.96` and `1.04` in the goal, `0.25` in `reference`). After changing a goal, upload again: the checker tells you if the mission can no longer be solved, or already passes at the start.
4. The 3D models: replace a file in `assets/` and update its line in `manifest.json` (name, credit, source). Before you build on a model, look at its size and where its origin is: a model's origin is wherever its maker left it. Only use files you have the right to use, and write the licence honestly.

## Rules the checker enforces

- Every name must be unique and written with lowercase letters, digits, `-` or `_`.
- Every mission must be solvable by its `reference`, and must not already pass at its `start`.
- A 3D picture needs at least one model in `assets`.
- Every file in `manifest.json` needs a licence, a credit and a source.

See `AUTHORING.md` for every key, with its limits and an example.
